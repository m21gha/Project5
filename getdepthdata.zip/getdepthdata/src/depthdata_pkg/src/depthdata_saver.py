#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import numpy as np
import cv2

depth_data_list = []  # A list to store the captured depth data

def depth_image_callback(data):
    # Create a CvBridge instance to convert ROS Image messages to OpenCV images
    bridge = CvBridge()

    try:
        # Convert the ROS Image message to an OpenCV image
        depth_image = bridge.imgmsg_to_cv2(data, desired_encoding="passthrough")

        # Append the depth data to the list
        depth_data_list.append(depth_image)

        # Save or use the processed depth image as needed
        # You can also transform it into a point cloud if required for your 3D reconstruction
        
        print("Number of depth images captured:", len(depth_data_list))
        
        save_depth_data()

    except Exception as e:
        rospy.logerr(e)

# Define a folder to save the depth images (change this path as needed)
save_folder = "/home/meghatron/depthimages"   
 
def save_depth_data():
    print("Number of depth images to save:", len(depth_data_list))
    for i, depth_image in enumerate(depth_data_list):
        try:
        # Define a file name for each depth image
            file_name = "depth_image_{}.npy".format(i)
        
        # Save the depth image as a NumPy array
            np.save(file_name, depth_image)
        
            print("Saved depth data to:", file_name)
        
        except Exception as e:
            print("Error saving depth data:", str(e))

def main():
    rospy.init_node('depth_data_capture_node', anonymous=True)
    rospy.Subscriber("/camera/depth/image_rect_raw", Image, depth_image_callback)

    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")


if __name__ == '__main__':
    main()